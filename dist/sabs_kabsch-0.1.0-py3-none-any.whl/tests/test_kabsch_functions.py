

# 2 check lengths of A and B are the same - NOTE move to tests?
assert len(A) == len(B)